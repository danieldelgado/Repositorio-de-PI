package com.sohlman.mockpoc.service;

/**
 * @author Sampsa Sohlman
 */
public interface Service {
	public String getName();
}
