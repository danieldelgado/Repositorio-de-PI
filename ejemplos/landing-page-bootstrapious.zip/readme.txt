################################################################################################

Documentation for Landing Page Theme by Bootstrapious - http://bootstrapious.com, rel. 2015/11/19

################################################################################################

Hi,

thank you for downloading. Have fun and tell your friends about us ;)

Ondrej from Bootstrapious


CSS
----------

The theme stylesheet is css/style.default.css. If you want to make any changes, you can do it here or better to override it in custom.css so you can update the original theme stylesheet if an updated is released.

Javascript
----------

Apart from Bootstrap JS components majority of JS is located in js/front.js. 

Credits
---------

- Botstrap 3.3.2
- Font Awesome 4.3.0
- Google Fonts - Roboto


---------------------
 LICENCE CONDITIONS
---------------------

You are completely free to use this template for your personal use or as a work for your client as long as you keep the link at the template footer pointing to us and our partner. If you want to remove the link, consider donating - http://bootstrapious.com/donate.

However you cannot redistribute the template as a template itself - neither for free or commercially (i.e. selling it on template marketplace).

Thank you for understanding and respecting the licence conditions.

---------------------
 GET IN TOUCH ;)
---------------------

https://twitter.com/bootstrapious | https://google.com/+Bootstrapious1 | https://www.facebook.com/bootstrapious | hello@bootstrapious.com
