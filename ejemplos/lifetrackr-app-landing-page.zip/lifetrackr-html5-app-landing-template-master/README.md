Lifetrakr html5 App landing template
=========
<img src="https://cloud.githubusercontent.com/assets/10640964/5989280/2eb3073a-a9ac-11e4-9fc9-7aad4e98c35d.jpg" />

<a style="text-align:center" href="http://themefisher.com/download/lifetrackr-app-landing-page/">Life Preview</a>
=========
Lifetrackr– is Responsive & Clean App Landing Page Template. It is based on Twitter Bootstrap v3.x. Lifetrackr is Well organized , very easy to customize and Perfect Choice for Your App Landing or Product Landing Page.
and much more …
