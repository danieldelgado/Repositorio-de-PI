<img src="https://cloud.githubusercontent.com/assets/10640964/5988570/4049a0a6-a990-11e4-9eff-7d65413105eb.jpg" />

<a href="http://themefisher.com/download/small-apps-html5-app-landing-page/" > Live Preview </a>

# small-apps
Smart App is a clean and modern Landing Page Template for Mobile App. Built with Bootstrap 3.Well organized and very easy to customize, Smart App is better way to present and promote your startup mobile app website.
Key Features
1 Clean Design – App-Plus have been crafted with great care and attention to make it clean.
2 Mobile Responsive – Fully responsive to meet the growing demand from the mobile market.
3 Built With Bootstrap – Bootstrap framework allows you to quickly kickstart any web development projects.
4 Fully Customizable – This template can be easily customized to fit your wants and needs.

PSD Credit:- http://www.psdbooster.com
